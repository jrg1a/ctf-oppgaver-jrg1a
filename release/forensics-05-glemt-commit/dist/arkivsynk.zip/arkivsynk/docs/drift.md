# Drift

Jobben kjører klokken 02:15 og skriver status til `logs/`.
