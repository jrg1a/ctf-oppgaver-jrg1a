# Arkivsynk

Lite verktøy for å kontrollere nattlige arkivjobber.
