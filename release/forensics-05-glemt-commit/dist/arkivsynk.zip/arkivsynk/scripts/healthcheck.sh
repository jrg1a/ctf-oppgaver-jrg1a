#!/bin/sh
echo arkivsynk: status=ok
