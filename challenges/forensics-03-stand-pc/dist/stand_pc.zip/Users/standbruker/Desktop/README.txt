Demo-PC fra Teknologidagene. Nettleserdata ble tatt vare paa for analyse.
