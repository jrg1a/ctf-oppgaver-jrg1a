Kopi av funnet USB-pinne. Ikke stol pa filnavn alene.
